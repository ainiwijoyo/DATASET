import pandas as pd
import numpy as np
from sklearn.cluster import KMeans

# Load data
df = pd.read_csv("./dataset/covid19_dtm2.csv", usecols=[ 'Case_Fatality_Rate', 'New_Cases'])

# Clean up the 'Case_Fatality_Rate' column
df['Case_Fatality_Rate'] = df['Case_Fatality_Rate'].str.replace('%', '').astype('float')

# Drop rows with missing values
df.dropna(subset=['Case_Fatality_Rate', 'New_Cases'], inplace=True)

# Convert data columns to numpy array
data = df.iloc[:, 1:].values

# Define number of clusters
k = 3

# Fit KMeans model to data
kmeans = KMeans(n_clusters=k, random_state=42).fit(data)

# Calculate cluster centers
centers = kmeans.cluster_centers_

# Define category ranges
low_range = np.max(centers) / 3
high_range = np.max(centers) * 2 / 3

# Input Case_Fatality_Rate and New_Cases value to determine its cluster category
input_cfr, input_new_cases = map(float, input("Input Case_Fatality_Rate and New_Cases value (separated by space): ").split())
input_data = np.array([[input_cfr, input_new_cases]])
input_cluster = kmeans.predict(input_data)[0]

# Map the input cluster to the corresponding category
categories = {0: "Low", 1: "Medium", 2: "High"}
input_category = categories[input_cluster]

print(f"The input data belongs to the {input_category} category.")
