import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import tornado.web
import numpy as np
import seaborn as sns
import plotly.express as px
from plotly import graph_objs as go
from sklearn.cluster import KMeans

st.set_page_config(page_title="Covid-19 Dashboard", page_icon=":chart_with_upwards_trend:", layout="wide")

# --- Load Data From CSV ----
@st.cache_data
def get_data_from_csv():
    df = pd.read_csv("./dataset/covid19_dtm2.csv")
    return df
df = get_data_from_csv()

# --- Header ---
st.header(":bar_chart: Indonesia Covid-19")
st.markdown("----")

# --- Informasi total data ---
total_case, total_recovered, total_death = st.columns(3)

total_case.metric("Total Kasus", df.New_Cases.sum())
total_recovered.metric("Total Sembuh",  df.New_Recovered.sum())
total_death.metric("Total Meninggal",  df.New_Deaths.sum())\

st.markdown("----")

# Tampilkan daftar provinsi
provinces = df['Province'].unique().tolist()
province_filter = st.sidebar.multiselect('Filter berdasarkan provinsi:', provinces)

# Filter data berdasarkan provinsi yang dipilih
if province_filter:
    df = df[df['Province'].isin(province_filter)]

# Tampilkan data yang sudah difilter
st.write(df)

st.markdown("---")
# --- sidebar ---
st.sidebar.write('Pilih Jenis Data:')
option_1 = st.sidebar.checkbox('Total Kasus')
option_2 = st.sidebar.checkbox('Kasus Harian')
option_3 = st.sidebar.checkbox('Total Sembuh')
option_4 = st.sidebar.checkbox('Sembuh Harian')
option_5 = st.sidebar.checkbox('Total Meninggal')
option_6 = st.sidebar.checkbox('Meninggal Harian')

fig_main = go.Figure()
if (option_1 or option_2 or option_3 or option_4 or option_4 or option_5 or option_6) is False:
    fig_main.add_trace(go.Scattergl(x=df['Date'], y=df['New_Cases'], name='Kasus Harian'))
    fig_main.add_trace(go.Scattergl(x=df['Date'], y=df['New_Recovered'], name='Sembuh Harian'))
else:
    if option_1:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['Total_Newcases'], name='Total Kasus'))
    if option_2:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['New_Cases'], name='Kasus Harian'))
    if option_3:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['Total_Recovered'], name='Total Sembuh'))
    if option_4:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['New_Recovered'], name='Sembuh Harian'))
    if option_5:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['Total_Deaths'], name='Total Meninggal'))
    if option_6:
        fig_main.add_trace(go.Scatter(x=df['Date'], y=df['New_Deaths'], name='Meninggal Harian'))
fig_main.layout.update(title_text='Indonesia Covid-19', 
                       xaxis_rangeslider_visible=True, 
                       hovermode='x',
                       legend_orientation='v')

st.plotly_chart(fig_main, use_container_width=True)

st.markdown("---")

provinsi_p = df.groupby('Province')['Total_Newcases'].sum().reset_index()

n_prov = st.slider('jumlah Provinsi:', 1, len(provinsi_p), 4)

top_prov = provinsi_p.nlargest(n_prov, 'Total_Newcases')

st.bar_chart(top_prov.set_index('Province'))

st.markdown("---")

# input untuk correlation matrix
import pandas as pd
import streamlit as st

df['Case_Fatality_Rate'] = df['Total_Deaths'] / df['Total_Cases'] * 100

if st.checkbox("Tampilkan korelasi matriks"):
    selected_cols = st.multiselect("Pilih kolom yang ingin dianalisis", df.columns.tolist() + ['Case_Fatality_Rate'])
    corr_method = st.selectbox("Metode korelasi", ("pearson", "kendall", "spearman"))

    if len(selected_cols) > 0:
        corr_data = df[selected_cols].corr(method=corr_method)
        st.write("Korelasi Matriks:")
        st.write(corr_data)
    else:
        st.warning("Silahkan pilih minimal 1 kolom untuk dianalisis.")

st.markdown("---")

# Load the dataset
@st.cache_data
def load_data():
    df = pd.read_csv('./dataset/covid19_dtm2.csv', nrows= 300)
    return df

df = load_data()

# Rename columns dan extract relevant features
df = df.rename(columns={'CFR': 'Case_Fatality_Rate', 'NC': 'New_Cases'})
df = df[['Province', 'Case_Fatality_Rate', 'New_Cases']]

# Clean  the 'Case_Fatality_Rate' column
df['Case_Fatality_Rate'] = df['Case_Fatality_Rate'].str.replace('%', '').astype('float')

# Drop rows missing values
df.dropna(inplace=True)

# Convert data columns to numpy array
data = np.array(df.iloc[:, 1:])

# Define number of clusters
k = 3

# Fit KMeans model to data
kmeans = KMeans(n_clusters=k, random_state=42).fit(data)

# Tetapkan setiap baris ke sebuah cluster
clusters = kmeans.predict(data)

# tambah cluster column ke DataFrame
df['Cluster'] = clusters

# Calculate cluster centers
centers = kmeans.cluster_centers_

# Define category ranges
low_range = np.max(centers) / 3
high_range = np.max(centers) * 2 / 3

# fungsi untuk menentukan kategori berdasarkan data input
def predict_category(cfr, new_cases):
    input_data = np.array([[cfr, new_cases]])
    input_cluster = kmeans.predict(input_data)
    
    if input_cluster == 0:
        return "Low"
    elif input_cluster == 1:
        return "Medium"
    else:
        return "High"

#judul cluster
st.title("COVID-19 Clustering")

# Show the dataset
st.write("Here's the dataset used for clustering:")
st.write(df)

# tampilkan cluster centers
st.write("cluster centers:")
st.write(centers)

#masukkan inputan
cfr_input = st.text_input("masukkan Case Fatality Rate (CFR) value:")
new_cases_input = st.text_input("masukkan New Cases value:")

# inputan diproses dan tampilkan
if st.button("Menentukan Tingkat Bahaya Suatu Daerah"):
    if cfr_input and new_cases_input:
        cfr = float(cfr_input)
        new_cases = float(new_cases_input)
        category = predict_category(cfr, new_cases)
        st.write(f"berdasarkan kategori CFR {cfr} dan New Cases {new_cases} , maka daerah ini memiliki tingkat Bahaya {category}.")
    else:
        st.write("masukkan lah data yang benar -_-")